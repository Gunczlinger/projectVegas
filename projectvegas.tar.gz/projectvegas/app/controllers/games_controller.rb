class GamesController < ApplicationController
    def index
        #Stuff and things here
    end
end